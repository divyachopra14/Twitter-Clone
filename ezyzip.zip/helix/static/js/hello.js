var counter=2;
setInterval(function(){document.title=counter+" notifications"; counter++},1000)